from flask import Flask, render_template, request, jsonify
from datetime import datetime

app = Flask(__name__)

# Educational demo only: this is not a medical diagnosis system.
FAQS = [
    (["fever", "temperature"], "A fever can have many causes. Rest, drink fluids, and monitor your temperature. Seek urgent care for severe symptoms, trouble breathing, confusion, a stiff neck, or a very high/persistent fever."),
    (["headache", "head pain"], "Headaches have many possible causes. Rest, hydration, and reducing screen strain may help. Seek urgent care for a sudden severe headache, weakness, confusion, vision loss, or a headache after a head injury."),
    (["cold", "cough", "sore throat"], "For mild cold symptoms, rest and fluids may help. Avoid close contact with others while ill. Get medical advice for breathing difficulty, chest pain, dehydration, worsening symptoms, or symptoms that persist."),
    (["stomach", "vomit", "nausea", "diarrhea"], "Try small sips of fluids if you can keep them down. Seek medical help for severe abdominal pain, blood in vomit or stool, fainting, or signs of dehydration."),
    (["sleep", "insomnia"], "A regular sleep schedule, a quiet dark room, and limiting caffeine late in the day can support sleep. If sleep problems continue or affect daily life, consult a healthcare professional."),
    (["stress", "anxiety"], "Slow breathing, a short walk, and talking with someone you trust may help with stress. If distress feels overwhelming or you may harm yourself, contact local emergency services or a crisis support service now."),
]

def make_reply(message):
    msg = message.lower()
    if any(word in msg for word in ["emergency", "can't breathe", "cannot breathe", "chest pain", "stroke", "unconscious", "severe bleeding"]):
        return ("Your message may describe an emergency. Please contact your local emergency number or go to the nearest emergency department now. "
                "Do not rely on this demo for urgent medical care.")
    for keywords, reply in FAQS:
        if any(word in msg for word in keywords):
            return reply
    return ("I can share general health information, but I can't diagnose a condition or recommend prescription treatment. "
            "Try asking about common topics such as fever, cold symptoms, headache, sleep, or stress. For personal symptoms, contact a qualified healthcare professional.")

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/chat", methods=["POST"])
def chat():
    data = request.get_json(silent=True) or {}
    message = (data.get("message") or "").strip()
    if not message:
        return jsonify({"reply": "Please type a question first."}), 400
    if len(message) > 1000:
        return jsonify({"reply": "Please keep your question under 1,000 characters."}), 400
    return jsonify({"reply": make_reply(message), "time": datetime.now().strftime("%H:%M")})

@app.route("/api/appointment", methods=["POST"])
def appointment():
    data = request.get_json(silent=True) or {}
    name = (data.get("name") or "").strip()
    contact = (data.get("contact") or "").strip()
    department = (data.get("department") or "").strip()
    date = (data.get("date") or "").strip()
    if not all([name, contact, department, date]):
        return jsonify({"message": "Please complete every field."}), 400
    # Demo only: no appointment is actually booked and no data is stored.
    return jsonify({"message": f"Demo request prepared for {name} in {department} on {date}. No appointment has been booked; connect a real clinic booking system to enable bookings."})

if __name__ == "__main__":
    app.run(debug=True)
