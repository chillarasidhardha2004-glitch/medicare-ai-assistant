const chatForm = document.getElementById("chat-form");
const input = document.getElementById("message-input");
const messages = document.getElementById("messages");

function addMessage(text, who) {
  const row = document.createElement("div");
  row.className = `message ${who}`;
  if (who === "bot") {
    const avatar = document.createElement("span");
    avatar.className = "avatar";
    avatar.textContent = "✚";
    row.appendChild(avatar);
  }
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.appendChild(document.createTextNode(text));
  const time = document.createElement("small");
  time.textContent = "Now";
  bubble.appendChild(time);
  row.appendChild(bubble);
  messages.appendChild(row);
  messages.scrollTop = messages.scrollHeight;
}

async function sendMessage(message) {
  const trimmed = message.trim();
  if (!trimmed) return;
  addMessage(trimmed, "user");
  input.value = "";
  input.disabled = true;
  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({message: trimmed})
    });
    const data = await response.json();
    addMessage(data.reply || "Sorry, something went wrong. Please try again.", "bot");
  } catch (error) {
    addMessage("I couldn't connect to the local server. Check that the Flask app is running, then try again.", "bot");
  } finally {
    input.disabled = false;
    input.focus();
  }
}
chatForm.addEventListener("submit", event => {
  event.preventDefault();
  sendMessage(input.value);
});
document.querySelectorAll("[data-prompt]").forEach(button => {
  button.addEventListener("click", () => sendMessage(button.dataset.prompt));
});

const appointmentForm = document.getElementById("appointment-form");
const appointmentResult = document.getElementById("appointment-result");
const dateInput = appointmentForm.querySelector('input[name="date"]');
dateInput.min = new Date().toISOString().slice(0, 10);

appointmentForm.addEventListener("submit", async event => {
  event.preventDefault();
  appointmentResult.textContent = "Preparing your demo request…";
  const payload = Object.fromEntries(new FormData(appointmentForm).entries());
  try {
    const response = await fetch("/api/appointment", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(payload)
    });
    const data = await response.json();
    appointmentResult.textContent = data.message || "Unable to prepare request.";
  } catch (error) {
    appointmentResult.textContent = "Could not connect to the local server. Please try again.";
  }
});
