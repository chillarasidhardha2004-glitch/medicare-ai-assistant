# MediCare AI Assistant Web Application

A responsive student-project demo built with **Python Flask, HTML, CSS, and JavaScript**.

## Features
- Responsive healthcare landing page
- Rule-based chat assistant for common general-health topics
- Quick question suggestions
- Demo appointment request form with validation
- Medical disclaimer and emergency guidance

## Run on Windows

1. Install Python 3.10 or later from https://www.python.org/downloads/ . During setup, enable **Add Python to PATH**.
2. Extract this project ZIP to a folder.
3. Open Command Prompt in that folder.
4. Create a virtual environment (recommended):
   ```bat
   py -m venv .venv
   .venv\Scripts\activate
   ```
5. Install dependencies:
   ```bat
   py -m pip install -r requirements.txt
   ```
6. Start the web application:
   ```bat
   py app.py
   ```
7. Open http://127.0.0.1:5000 in your browser.

## Run on macOS/Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Then open http://127.0.0.1:5000.

## Project structure

```text
MediCare_AI_Assistant/
├── app.py
├── requirements.txt
├── README.md
├── templates/
│   └── index.html
└── static/
    ├── style.css
    └── app.js
```

## Important notes
- The chat uses simple keyword matching; it is not a trained medical AI model.
- The appointment form is a demo only. It does not book real appointments or save submitted information.
- Do not enter private or identifying medical details.
- This project is not a medical device and does not diagnose or treat disease.
- Before deployment, turn off Flask debug mode, add security controls, and have qualified clinicians review any health content.
